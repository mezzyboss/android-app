package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText BillTotal;
    private EditText peopleNum;
    private TextView tipAmount;
    private TextView totwTip;
    private TextView totPp;
    private TextView overAge;
    private String tiptext, totPP, total, ovg;
    private Double val;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BillTotal = findViewById(R.id.inputval);
        peopleNum = findViewById(R.id.inputval2);
        tipAmount = findViewById(R.id.tipam);
        totwTip = findViewById(R.id.textView10);
        totPp = findViewById(R.id.textView11);
        overAge = findViewById(R.id.textView12);
    }

    public void calcTip(View v){
        String conv = BillTotal.getText().toString();
        if(conv.isEmpty() == true) {
            return;
        }
        Log.d(TAG, "calcTip");
        val = Double.parseDouble(conv);
        if(v.getId() == R.id.twelvepercent){
            tipAmount.setText(String.format("%.2f", val * 0.12));
            totwTip.setText(String.format("%.2f", val * 1.12));
        }else if(v.getId() == R.id.fifteenpercent){
            tipAmount.setText(String.format("%.2f", val * 0.15));
            totwTip.setText(String.format("%.2f", val * 1.15));
        }else if(v.getId() == R.id.eighteenpercent){
            tipAmount.setText(String.format("%.2f", val * 0.18));
            totwTip.setText(String.format("%.2f", val * 1.18));
        }else if(v.getId() == R.id.twentypercent){
            tipAmount.setText(String.format("%.2f", val * 0.2));
            totwTip.setText(String.format("%.2f", val * 1.2));
        }

    }

    @Override
    public void onRestoreInstanceState(@Nullable Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        tiptext = savedInstanceState.getString(tiptext);
        total = savedInstanceState.getString(total);
        totPP = savedInstanceState.getString(totPP);
        ovg= savedInstanceState.getString(ovg);

    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        tiptext = tipAmount.getText().toString();
        total = totwTip.getText().toString();
        totPP = totPp.getText().toString();
        ovg = overAge.getText().toString();
        outState.putString("tip amount", tiptext);
        outState.putString("total", total);
        outState.putString("totperperson", totPP);
        outState.putString("overage", ovg);
    }

    public void setTIp(View v){
        String conv = peopleNum.getText().toString();
        if(conv.isEmpty() == true) {
            return;
        }
        Log.d(TAG, "calcTip");
        double ans = Double.parseDouble(conv);
        totPp.setText(String.format("%.2f", val/ans));
        overAge.setText(String.format("%f", (val/ans) - Math.round(val/ans * 1.00)));
    }

    public void clearAll(View v){
        BillTotal.setText("");
        peopleNum.setText("");
        tipAmount.setText("");
        totwTip.setText("");
        totPp.setText("");
        overAge.setText("");
    }


}